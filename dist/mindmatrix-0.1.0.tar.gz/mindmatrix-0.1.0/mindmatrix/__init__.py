from .core import mindmatrix, analyze_patterns, decompose, approximate_product, combine, error_correction
